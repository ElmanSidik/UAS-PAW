<?php
   include 'koneksi.php';
   
   if(isset($_POST['aksi'])){
    if($_POST['aksi'] == "add"){
        
        
        $nama_beasiswa = $_POST['nama_beasiswa'];
        $deadline_beasiswa = $_POST['deadline_beasiswa'];
        $poster_beasiswa = $_FILES['poster_beasiswa']['name'];
        $link_beasiswa = $_POST['link_beasiswa'];
        $deskripsi_beasiswa = $_POST['deskripsi_beasiswa'];

        $dir = "img/";
        $tmpFile =$_FILES['poster_beasiswa']['tmp_name'];

        move_uploaded_file($tmpFile,$dir. $poster_beasiswa);

        //die();

        $query = "INSERT INTO dt_beasiswa VALUES(null, '$nama_beasiswa',' $deskripsi_beasiswa','$deadline_beasiswa','$poster_beasiswa',' $link_beasiswa')";
        $sql = mysqli_query($conn, $query);

        if($sql){
            header("location: index.php");
            //echo "Data Berhasil Ditambahkan <a href='index.php'>[Home]</a>";
        }else{
            echo $query;
        }

        //echo $nama_beasiswa." | ".$deadline_beasiswa." | ".$poster_beasiswa." | ".$link_beasiswa." | ".$deskripsi_beasiswa;

        //echo" <br>Tambah Data <a href='index.php'>[Home]</a>";
    }else if($_POST['aksi'] == "edit"){
        //echo"Edit Data <a href='index.php'>[Home]</a>";
        //var_dump($_POST);
        $id_beasiswa = $_POST['id_beasiswa'];
        $nama_beasiswa = $_POST['nama_beasiswa'];
        $deadline_beasiswa = $_POST['deadline_beasiswa'];
        //$poster_beasiswa = $_FILES['poster_beasiswa']['name'];
        $link_beasiswa = $_POST['link_beasiswa'];
        $deskripsi_beasiswa = $_POST['deskripsi_beasiswa'];
        
        $queryShow = "SELECT * FROM dt_beasiswa WHERE id_beasiswa = '$id_beasiswa';";
        $sqlShow = mysqli_query($conn,$queryShow);
        $result = mysqli_fetch_assoc($sqlShow);

        if($_FILES['poster_beasiswa'] ['name'] == ""){
            $poster_beasiswa =$result['poster_beasiswa'];
        }else{
            $poster_beasiswa =$_FILES['poster_beasiswa']['name'];
            unlink("img/".$result['poster_beasiswa']);
            move_uploaded_file($_FILES['poster_beasiswa']['tmp_name'],'img/'.$_FILES['poster_beasiswa']['name']);
        }
        

        $query = "UPDATE dt_beasiswa SET nama_beasiswa='$nama_beasiswa',deadline_beasiswa='$deadline_beasiswa',poster_beasiswa ='$poster_beasiswa',link_beasiswa='$link_beasiswa',deskripsi_beasiswa='$deskripsi_beasiswa' WHERE id_beasiswa='$id_beasiswa';";
        $sql =mysqli_query($conn,$query);
        header("location: index.php");

    }
   }

   if(isset($_GET['hapus'])){
    $id_beasiswa = $_GET['hapus'];

    $queryShow = "SELECT * FROM dt_beasiswa WHERE id_beasiswa = '$id_beasiswa';";
    $sqlShow = mysqli_query($conn,$queryShow);
    $result = mysqli_fetch_assoc($sqlShow);

    var_dump($sqlShow);
    unlink("img/".$result['poster_beasiswa']);
    

    $query = "DELETE FROM dt_beasiswa WHERE id_beasiswa ='$id_beasiswa';";
    $sql = mysqli_query($conn, $query);


    
    if($sql){
        header("location: index.php");
        //echo "Data Berhasil Ditambahkan <a href='index.php'>[Home]</a>";
    }else{
        echo $query;
    }
    //echo"Hapus Data <a href='index.php'>[Home]</a>";
   }
?>