<!DOCTYPE html>

<?php
        include 'koneksi.php';
        session_start();

      

        $id_beasiswa = '';
        $nama_beasiswa = '';
        $deadline_beasiswa = '';
        $poster_beasiswa = '';
        $link_beasiswa = '';
        $deskripsi_beasiswa = '';


        if(isset($_GET['ubah'])){
          $id_beasiswa = $_GET['ubah'];
          
          $query = "SELECT * FROM dt_beasiswa WHERE id_beasiswa = '$id_beasiswa';";
          $sql = mysqli_query($conn, $query);

          $result = mysqli_fetch_assoc($sql);

      
          $nama_beasiswa = $result['nama_beasiswa'];
          $deadline_beasiswa = $result['deadline_beasiswa'];
          //$poster_beasiswa = $result['poster_beasiswa']['name'];
          $link_beasiswa = $result['link_beasiswa'];
          $deskripsi_beasiswa = $result['deskripsi_beasiswa'];

         // var_dump($result);

          //die();
        }
?>

<html>
    <head>
        <meta charset="utf-8">
        <link href="css/bootstrap.min.css" rel="stylesheet" >
        <script src="js/bootstrap.bundle.min.js"></script>
        <link rel="icon" href="img/icon.png" type="image/x-icon">
        
        <link rel="stylesheet" href="fontawesome/css/font-awesome.min.css">

        <title>MyBeasiswa</title>
    </head>

    <body>
        <nav class=" navbar navbar-light bg-light mb-4">
            <div class="container-fluid">
              <a class="navbar-brand" href="#">
                <img src="img/icon.png" alt="Logo" width="30" height="35" class="d-inline-block align-text-top">
                MyBeasiswa CRUD
              </a>
            </div>
          </nav>
        <div class="container">
           <form method="POST" action="proses.php" enctype="multipart/form-data">
            <input type="hidden" value="<?php echo $id_beasiswa; ?>" name="id_beasiswa">
           <div class="mb-3 row">
                <label for="nama" class="col-sm-2 col-form-label">Nama Beasiswa</label>
                <div class="col-sm-10">
                  <input required type="text" name="nama_beasiswa" class="form-control" id="nama" placeholder="Nama Beasiswa" value="<?php echo $nama_beasiswa;?>">
                </div>
            </div>
            <div class="mb-3 row">
                <label for="dealine" class="col-sm-2 col-form-label">Deadline Pendaftaran</label>
                <div class="col-sm-10">
                  <input required type="text" name="deadline_beasiswa" class="form-control" id="deadline" placeholder="12 November 2023" value="<?php echo $deadline_beasiswa;?>">
                </div>
            </div>
            <div class="mb-3 row">
                <label for="nama" class="col-sm-2 col-form-label">Poster Beasiswa</label>
                <div class="col-sm-10">
                <input <?php if(!isset($_GET['ubah'])){ echo "required ";}?>type="file" name="poster_beasiswa" class="form-control" id="poster_beasiswa" accept="image/*" >
                </div>
            </div>
            <div class="mb-3 row">
                <label for="link" class="col-sm-2 col-form-label">Link Beasiswa</label>
                <div class="col-sm-10">
                  <input required type="text" name="link_beasiswa" class="form-control" id="link" placeholder="https://" value="<?php echo $link_beasiswa;?>">
                </div>
            </div>
            <div class="mb-3 row">
                <label for="deskripsi" class="col-sm-2 col-form-label">Deskripsi Beasiswa</label>
                <div class="col-sm-10">
                  <textarea required class="form-control" name="deskripsi_beasiswa" id="deskripsi" rows="3" ><?php echo   $deskripsi_beasiswa;?></textarea>
                </div>
            </div>
            <div class="mb-3 row mt-4">
                <div class="col">

                  <?php
                          if(isset($_GET['ubah'])){
                  ?>
                           <button type="submit" name="aksi" value="edit" class="btn btn-primary">
                               <i class="fa fa-floppy-o" aria-hidden="true"></i>
                                Simpan Perubahan
                           </button>
                    <?php
                     }else{
                     ?>
                            <button type="submit" name="aksi" value="add"  class="btn btn-primary">
                               <i class="fa fa-floppy-o" aria-hidden="true"></i>
                                Tambahkan
                           </button>
                    <?php
                     }
                     ?>

                    <a href="index.php" htype="button" class="btn btn-danger">
                        <i class="fa fa-reply" aria-hiden="true"></i>
                        Batal
                    </a>
                </div>
            </div>
           </form>
        </div>
    </body>
</html>