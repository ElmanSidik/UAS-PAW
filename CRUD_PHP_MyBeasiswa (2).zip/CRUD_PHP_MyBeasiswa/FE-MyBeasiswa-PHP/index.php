<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <link rel="icon" href="img/icon.png" type="image/x-icon">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <script src="js/bootstrap.bundle.min.js"></script>
        <link rel="stylesheet" href="fontawesome/css/font-awesome.min.css">
        <link rel="stylesheet" href="style.css">
        <script src="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.js"></script>
        <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
        <!-- Link Swiper's CSS -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.css"/>
         <!-- CSS -->
        <link rel="stylesheet" href="css/styles.css">
        <title>MyBeasiswa</title>

    
    </head>

<body>
    <nav class="navbar">
        <a class="navbar-brand">
            <img class="logo" src="img/icon.png">
            MyBeasiswa
        </a>
        <a class="home">Home</a>
        <a class="contact" href="contact.php">Contact</a>
        <a class="profile" href="profile.php">Profile</a>
        <form class="d-flex" role="search">
            <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
            <button class="btn btn-outline-primary" type="submit">Search</button>
        </form>
    </nav>
    
    <nav class="header">
    <img src="img/My.png" class="img-fluid">
    <h1 class="mybeasiswa">MyBeasiswa</h1>
    <h4 class="deskripsi-my">Temukan peluang pendidikan terbaik </h4>
    <h4 class="deskripsi-my-1">untuk massa depanmu.</h4>
    <a href="seall.php" type="button-seAll" class="btn btn-light">See All</a>
    
    
    <img src="img/graduation-2.jpg" class="graduation">
    <p class="deskripsi">Selamat datang di MyBeasiswa, sumber informasi terpercaya untuk<br>
        mendapatkan akses berbagai peluang beasiswa! Kami berkomitmen<br>
        untuk menyediakan panduan lengkap dan terkini tentang berbagai<br>
        beasiswa yang dapat membantu mewujudkan impian pendidikan Anda.</p>
    <h3 class="deskripsi-mybeasiswa">MyBeasiswa</h3>
    <h1 class="daftar-mybeasiswa">Daftar Beasiswa</h1>

    <section class="swiper mySwiper">

        <div class="swiper-wrapper">
    
          <div class="card swiper-slide">
            <div class="card__image">
              <img src="../img/BSI-Scolar.jpg" alt="card image">
            </div>
    
            <div class="card__content">
              <span class="card__title">BSI Scholarship</span>
              <span class="card__name">Deadline:30 Desember 2023</span>
              <p class="card__text">BSI Scholarship adalah program beasiswa jenjang Sarjana (S1) yang dikelola oleh BSI Maslahat dan Bank Syariah Indonesia.Beasiswa meliputi BSI Prestasi dan BSI Inspirasi.</p>
              <button class="card__btn">View More</button>
            </div>
          </div>
    
          <div class="card swiper-slide">
            <div class="card__image">
              <img src="../img/beasiswa-unggulan-kemendikbud.png" alt="card image">
            </div>
    
            <div class="card__content">
              <span class="card__title">Unggulan</span>
              <span class="card__name">Deadline:7 September 2023</span>
              <p class="card__text">Beasiswa Unggulan merupakan program pemberian biaya pendidikan dari pemerintah Indonesia untuk putra-putri bangsa pada perguruan tinggi.</p>
              <button class="card__btn">View More</button>
            </div>
          </div>
    
          <div class="card swiper-slide">
            <div class="card__image">
              <img src="../img/BRI_Scolar.jpg" alt="card image">
            </div>
    
            <div class="card__content">
              <span class="card__title">BRIlian Scholarship</span>
              <span class="card__name">Deadline:5 Juli 2023</span>
              <p class="card__text">BRIlian Scholarship Program (BSP) adalah program beasiswa yang berasal dari BRI,diperuntukan bagi mahasiswa S1 untuk meningkatkan kompetensi Penerima BRILiaN.</p>
              <button class="card__btn">View More</button>
            </div>
          </div>
    
          <div class="card swiper-slide">
            <div class="card__image">
              <img src="../img/JFLS.jpg" alt="card image">
            </div>
    
            <div class="card__content">
              <span class="card__title">Beasiswa JFLS</span>
              <span class="card__name">Deadline:10 Agustus 2023</span>
              <p class="card__text">Merupakan program bantuan biaya pendidikan tinggi dari Pemerintah Provinsi Jawa Barat melalui Dinas Pendidikan untuk masyarakat jabar di bidang akademik & non-akademik.</p>
              <button class="card__btn">View More</button>
            </div>
          </div>
    
        </div>
      </section>


   

       <!--
          <div class="card">
            <img src="img/graduation.jpg" class="card-img-top" style="margin-top: 5%;">
            <div class="card-body">
              <h5 class="card-title">Card title</h5>
              <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
              <button type="button" class="btn btn-primary" style="margin-left: 26%;">Info Selengkapnya</button>
            </div>
          </div> -->
    
    <h1 class="alur-h1">4-ALUR SELEKSI BEASISWA</h1>
    <img src="img/2-removebg.png" class="alur">
    </nav>

    <nav class="footer">
    <div class="rectangle-1-AE1">
    <p class="temukan-peluang-pendidikan-untuk-masa-depanmu-gCM" style="margin-top: 9%;margin-left:-8%;">
    Temukan peluang pendidikan untuk
    <br/>
     masa depanmu.
    </p>
    <div class="ellipse-1-YEZ">
    </div>
    <div class="ellipse-2-3SD">
    </div>
    <div class="ellipse-3-NDb">
    </div>
    <p class="ikuti-kami-di-Vp1">Ikuti Kami di</p>
    <img class="image-1-o41" src="img/image-1.png">
    <img class="image-2-74h" src="img/image-2.png">
    <img class="image-3-qmP" src="img/image-3.png">
    <p class="mybeasiswa-Jey"  style="margin-left:-4.6%">MyBeasiswa</p>
    <img class="copyright-1-RDo" src="img/copyright-1.png" style="margin-left:-4.6%">
    
    <p class="mybeasiswa-XXj" style="margin-left:-8%">MyBeasiswa</p>
    <img class="graduation-cap-1-1-qYR" src="img/icon.png" style="margin-left:-2%">
  </div>  
    </nav>



<!-- Swiper JS -->
<script src="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.js"></script>

<!-- Initialize Swiper -->
<script>
  var swiper = new Swiper(".mySwiper", {
    effect: "coverflow",
    grabCursor: true,
    centeredSlides: true,
    slidesPerView: "auto",
    coverflowEffect: {
      rotate: 0,
      stretch: 0,
      depth: 300,
      modifier: 1,
      slideShadows: false,
    },
    pagination: {
      el: ".swiper-pagination",
    },
  });



  $(document).ready(function() {
        // Tangkap elemen formulir pencarian
        var searchForm = $('form[role="search"]');

        // Tangkap elemen input pencarian
        var searchInput = searchForm.find('input[type="search"]');

        // Tangkap elemen kontainer kartu
        var cardContainer = $('.card-container');

        // Tangkap semua kartu
        var cards = $('.card');

        // Tangkap elemen tombol pencarian
        var searchButton = searchForm.find('button[type="submit"]');

        // Atur tindakan pencarian saat formulir dikirim
        searchForm.submit(function(e) {
            e.preventDefault(); // Mencegah pengiriman formulir yang normal

            // Dapatkan nilai input pencarian
            var searchTerm = searchInput.val().toLowerCase();

            // Sembunyikan semua kartu
            cards.hide();

            // Tampilkan kartu yang sesuai dengan pencarian
            cards.filter(function() {
                var cardText = $(this).text().toLowerCase();
                return cardText.includes(searchTerm);
            }).show();
        });
    });
</script>


    
</body>
</html>
