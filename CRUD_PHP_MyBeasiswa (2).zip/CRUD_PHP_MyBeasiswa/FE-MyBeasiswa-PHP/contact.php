<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="icon" href="img/icon.png" type="image/x-icon">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <script src="js/bootstrap.bundle.min.js"></script>
        <link rel="stylesheet" href="fontawesome/css/font-awesome.min.css">
        <link rel="stylesheet" href="style.css">
        <script src="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.js"></script>
        <!-- Link Swiper's CSS -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.css"/>
         <!-- CSS -->
        <link rel="stylesheet" href="css/styles.css">
        <title>See All</title>
    </head>
    <body>
        <nav class="navbar">
            <a class="navbar-brand">
                <img class="logo" src="img/icon.png">
                MyBeasiswa
            </a>
            <a class="home" href="index.php"  style="margin-left: 25%;">Home</a>
            <a class="contact" href="contact.php">Contact</a>
            <a class="profile"href="profile.php">Profile</a>
            <form class="d-flex" role="search">
                
            </form>
        </nav>

 

        <nav class="header">
        <h2 style="margin-left:45%; color: white; margin-top: 3%;">Contact</h2>
          <div class="card" style="margin-top: 5%; width: 80%; height: 100%;margin-left: 9%;">
        <h2>email :elmansidiq4@gmail.com</h2>
           
          </div>
        </nav>

       

        <nav class="footer" style="margin-top: 10%;">
            <div class="rectangle-1-AE1">
            <p class="temukan-peluang-pendidikan-untuk-masa-depanmu-gCM">
            Temukan peluang pendidikan untuk
            <br/>
             masa depanmu.
            </p>
            <div class="ellipse-1-YEZ">
            </div>
            <div class="ellipse-2-3SD">
            </div>
            <div class="ellipse-3-NDb">
            </div>
            <p class="ikuti-kami-di-Vp1">Ikuti Kami di</p>
            <img class="image-1-o41" src="img/image-1.png">
            <img class="image-2-74h" src="img/image-2.png">
            <img class="image-3-qmP" src="img/image-3.png">
            <p class="mybeasiswa-Jey">MyBeasiswa</p>
            <img class="copyright-1-RDo" src="img/copyright-1.png">
            <p class="mybeasiswa-XXj">MyBeasiswa</p>
            <img class="graduation-cap-1-1-qYR" src="img/icon.png">
          </div>  
            </nav>

    </body>
</html>