<?php
require_once '../koneksi.php';

session_start();

$query = "SELECT * FROM dt_beasiswa;";
$sql = mysqli_query($conn, $query);

$no = 0;

echo '<div class="card-container" style="display: flex; flex-wrap: wrap; justify-content: space-between;">';
while ($result = mysqli_fetch_assoc($sql)) {
    $no++;

    echo '<div class="card" style="width: 22%; margin-bottom: 5px; margin: 20px;margin-top:8.9%; margin-left:1%;">';
    echo '<img src="../img/' . $result['poster_beasiswa'] . '" class="card-img-top" alt="..." style="margin-top:4%;">';
    echo '<div class="card-body">';
    echo '<h3 class="card-title">' . $result['nama_beasiswa'] . '</h3>';
    echo '<p class="card-text">' . $result['deskripsi_beasiswa'] . '</p>';
    echo '<h5 class="card-title">Deadline: ' . $result['deadline_beasiswa'] . '</h5>';
    echo '<a href="' . $result['link_beasiswa'] . '" class="btn btn-primary">Info Selengkapnya</a>';
    echo '</div>';
    echo '</div>';
}
echo '</div>';
?>


<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="icon" href="img/icon.png">
        <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <script src="js/bootstrap.bundle.min.js"></script>
        <link rel="stylesheet" href="fontawesome/css/font-awesome.min.css">
        <link rel="stylesheet" href="style.css">
        <title>See All</title>
    </head>
    <body>

    <nav class="navbar" style="margin-top:-98.2%">
        <a class="navbar-brand">
            <img class="logo" src="img/icon.png">
            MyBeasiswa
        </a>
        <a class="home" href="index.php">Home</a>
        <a class="contact" href="contact.php">Contact</a>
        <a class="profile" href="profile.php">Profile</a>
        <form class="d-flex" role="search">
            <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
            <button class="btn btn-outline-primary" type="submit">Search</button>
        </form>
    </nav>





 
  

<script>
    $(document).ready(function() {
        // Tangkap elemen formulir pencarian
        var searchForm = $('form[role="search"]');

        // Tangkap elemen input pencarian
        var searchInput = searchForm.find('input[type="search"]');

        // Tangkap elemen kontainer kartu
        var cardContainer = $('.card-container');

        // Tangkap semua kartu
        var cards = $('.card');

        // Tangkap elemen tombol pencarian
        var searchButton = searchForm.find('button[type="submit"]');

        // Atur tindakan pencarian saat formulir dikirim
        searchForm.submit(function(e) {
            e.preventDefault(); // Mencegah pengiriman formulir yang normal

            // Dapatkan nilai input pencarian
            var searchTerm = searchInput.val().toLowerCase();

            // Sembunyikan semua kartu
            cards.hide();

            // Tampilkan kartu yang sesuai dengan pencarian
            cards.filter(function() {
                var cardText = $(this).text().toLowerCase();
                return cardText.includes(searchTerm);
            }).show();
        });
    });
</script>




 



</body>
</html>