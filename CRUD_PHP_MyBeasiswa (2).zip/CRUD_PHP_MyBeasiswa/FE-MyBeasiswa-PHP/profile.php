<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="icon" href="img/icon.png" type="image/x-icon">
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <script src="js/bootstrap.bundle.min.js"></script>
        <link rel="stylesheet" href="fontawesome/css/font-awesome.min.css">
        <link rel="stylesheet" href="style.css">
        <script src="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.js"></script>
        <!-- Link Swiper's CSS -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.css"/>
         <!-- CSS -->
        <link rel="stylesheet" href="css/styles.css">
        <title>See All</title>
    </head>
    <body>
        <nav class="navbar">
            <a class="navbar-brand">
                <img class="logo" src="img/icon.png">
                MyBeasiswa
            </a>
            <a class="home" href="index.php"  style="margin-left: 25%;">Home</a>
            <a class="contact" href="contact.php">Contact</a>
            <a class="profile" href="profile.php">Profile</a>
            <form class="d-flex" role="search">
                
            </form>
        </nav>

 

        <nav class="header">
            <h4 style="color: wheat; margin-left: 45%; margin-top: 5%;">Tentang</h4>
            <img src="img/graduation.jpg" class="graduation" style="margin-top: 7%">
            <p class="deskripsi" style="margin-top: -15%;">
                MyBeasiswa adalah platform daring yang menyediakan informasi lengkap tentang<br>
                berbagai beasiswa untuk membantu para pelajar dan profesional mencapai impian<br>
                akademis mereka.Dengan basis data yang luas dan antarmuka yang ramah pengguna,<br>
                MyBeasiswa memudahkan pencarian,aplikasi,dan pelacakan status beasiswa.</p>
            <h4 style="color: wheat; margin-left: 45%; margin-top: 20%;">Tujuan</h4>
            <p class="deskripsi" style="margin-top: 5%;">
                1.Memberikan akses mudah dan cepat ke informasi terkini tentang berbagai jenis beasiswa.<br>
                2.Membantu pemohon beasiswa menemukan peluang pendidikan yang sesuai dengan minat, keahlian,<br>
                  dan tingkat pendidikan mereka.<br>
                3.Menyediakan panduan langkah-demi-langkah untuk proses aplikasi beasiswa.<br>
                4.Mendorong keterlibatan komunitas dan berbagi pengalaman melalui forum dan ulasan.<br>
            </p>
            
               
        </nav>

       

        <nav class="footer" style="margin-top: 20%;">
            <div class="rectangle-1-AE1">
            <p class="temukan-peluang-pendidikan-untuk-masa-depanmu-gCM">
            Temukan peluang pendidikan untuk
            <br/>
             masa depanmu.
            </p>
            <div class="ellipse-1-YEZ">
            </div>
            <div class="ellipse-2-3SD">
            </div>
            <div class="ellipse-3-NDb">
            </div>
            <p class="ikuti-kami-di-Vp1">Ikuti Kami di</p>
            <img class="image-1-o41" src="img/image-1.png">
            <img class="image-2-74h" src="img/image-2.png">
            <img class="image-3-qmP" src="img/image-3.png">
            <p class="mybeasiswa-Jey">MyBeasiswa</p>
            <img class="copyright-1-RDo" src="img/copyright-1.png">
            <p class="mybeasiswa-XXj">MyBeasiswa</p>
            <img class="graduation-cap-1-1-qYR" src="img/icon.png">
          </div>  
            </nav>

    </body>
</html>