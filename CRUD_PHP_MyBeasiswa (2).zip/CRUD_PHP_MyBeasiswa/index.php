<?php
    include 'koneksi.php';
    session_start();

    $query = "SELECT * FROM dt_beasiswa;";
    $sql = mysqli_query($conn, $query);
    $no = 0;
?>




<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <link href="css/bootstrap.min.css" rel="stylesheet" >
        <script src="js/bootstrap.bundle.min.js"></script>
        
        <link rel="stylesheet" href="fontawesome/css/font-awesome.min.css">


        <link rel="stylesheet"type="text/css"href="datatables/datatables.css">
        <script type="text/javascript" src="datatables/datatables.js"></script>


        <title>MyBeasiswa</title>
    </head>

    <script type="text/javascript">
           $(document).ready(function(){
            $('#dt').DataTable();
           });
    </script>

    <body style="background-color: lightblue;">
        <nav class="navbar bg-light">
            <div class="container-fluid">
              <a class="navbar-brand" href="#">
                <img src="img/icon.png" alt="Logo" width="30" height="35" class="d-inline-block align-text-top">
                MyBeasiswa CRUD
              </a>
            </div>
          </nav>

        
        <div class="container">
              <h1 class="mt-4" style="margin-left:40%">Data Beasiswa</h1>
          <figure>
            <blockquote class="blockquote" style="margin-left:40%">
              <p>Daftar Beasiswa Di Database</p>
            </blockquote>
            <figcaption class="blockquote-footer"style="margin-left:42%">
              CRUD<cite title="Source Title" style="margin-left:1%">Create Update Delete</cite>
            </figcaption>
          </figure>
              <a href="kelola.php" type="button" class="btn btn-primary mb-3">
                <i class="fa fa-plus"></i>
                Tambah Data
              </a>
              



              <div class="table-responsive">
                <table id="dt" class="table align-middle table-bordered table-hover" style="background-color: white;">
                  <thead>
                    <tr>
                      <th><center>No.</center></th>
                      <th>Nama Beasiswa</th>
                      <th>Deadline Pendaftaran</th>
                      <th>Deskripsi</th>
                      <th>Poster</th>
                      <th>Link</th>
                      <th>Aksi</th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php
                       while ($result = mysqli_fetch_assoc($sql)){
                  ?>
                    <tr>
                      <td><center>
                        <?php echo ++$no; ?>
                        .
                      </center></td>
                      <td>
                      <?php echo $result['nama_beasiswa']; ?>
                      </td>
                      <td><?php echo $result['deadline_beasiswa']; ?></td>
                      <td>
                      <?php echo $result['deskripsi_beasiswa']; ?>
                      </td>
                      <td>
                        <img src="img/<?php echo $result['poster_beasiswa']; ?>"  style="width: 200px;">
                      </td>
                      <td><?php echo $result['link_beasiswa']; ?></td>
                      
                      <td>
                        <a href="kelola.php?ubah=<?php echo $result['id_beasiswa']; ?>" type="button" class="btn btn-success btn-sm">
                            <i class="fa fa-pencil"></i>
                        </a>
                        <a href="proses.php?hapus=<?php echo $result['id_beasiswa']; ?>" type="button" class="btn btn-danger btn-sm" onClick="return confirm('Apakah anda yakin ingin menghapus data tersebut ?')" style="margin-top:10%">
                            <i class="fa fa-trash"></i>
                        </a>
                      </td>
                    </tr>

                  <?php
                       }
                  ?>
                  </tbody>
                </table>
              </div>
            </div>
    </body>
</html>